/* ============================================================================
   KNIGHT ASSISTANT — search bar + mic + location + "Hey Knight" AI mode
   Loaded after script.js, so it reuses its helpers: $, toast, me, requireAuth,
   openKnightPage, goHome, signOutUI, callAI, aiMode, setStudioTab, renderStudio.
   AI replies go through the same callAI() as the rest of the site, so the
   OpenRouter key stays on the server (or in the user's own browser).
============================================================================ */
(function () {
  'use strict';
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const kn = { loc: null, aiOn: false, wake: false, wakeRec: null, oneRec: null, idleTimer: null,
               spoken: false, history: [], awaitingCmd: false };

  /* ----- the pages the assistant can open ---------------------------------- */
  const PAGES = [
    { id: 'terminalPage', words: ['terminal', 'code', 'cli', 'console'] },
    { id: 'projectsPage', words: ['projects', 'project manager', 'repos', 'repositories'] },
    { id: 'studioPage',   words: ['studio', 'discover', 'explore'] },
    { id: 'commPage',     words: ['communication', 'chat', 'messages'] },
    { id: 'socialPage',   words: ['social', 'friends'] },
    { id: 'notesPage',    words: ['notes', 'database', 'data base', 'snippets'] },
    { id: 'arcadePage',   words: ['arcade', 'game', 'games'] },
    { id: 'gameBoosterPage', words: ['booster', 'game booster'] },
    { id: 'settingsPage', words: ['settings', 'preferences'] },
  ];

  /* ----- UI helpers ------------------------------------------------------- */
  function log(kind, text) {
    const box = $('knLog'); if (!box) return;
    const d = document.createElement('div');
    d.className = 'kn-msg ' + kind; d.textContent = text;
    box.appendChild(d); box.scrollTop = box.scrollHeight;
    while (box.children.length > 60) box.removeChild(box.firstChild);
  }
  function say(text, speak) {
    log('ai', text);
    if (speak && 'speechSynthesis' in window) {
      try { speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(text.slice(0, 400)); u.rate = 1.03; speechSynthesis.speak(u); } catch (_) {}
    }
  }
  function bumpIdle() {
    clearTimeout(kn.idleTimer);
    if (kn.aiOn) kn.idleTimer = setTimeout(() => setAiMode(false, true), 60000);
  }
  function setAiMode(on, announce) {
    kn.aiOn = on;
    document.body.classList.toggle('knight-ai', on);
    const dock = $('knDock'); if (dock) dock.classList.toggle('show', on);
    const w = $('knWakeBtn'); if (w) w.classList.toggle('on', kn.wake || on);
    if (on) { bumpIdle(); } else { clearTimeout(kn.idleTimer); kn.awaitingCmd = false; try { speechSynthesis.cancel(); } catch (_) {} }
    if (!on && announce) toast('Knight AI mode off.');
  }

  /* ----- location --------------------------------------------------------- */
  function getLocation(quiet) {
    return new Promise((resolve) => {
      if (!navigator.geolocation) { if (!quiet) toast('Geolocation is not available in this browser.', true); return resolve(null); }
      navigator.geolocation.getCurrentPosition(
        (p) => {
          kn.loc = { lat: p.coords.latitude, lng: p.coords.longitude, acc: Math.round(p.coords.accuracy || 0) };
          const chip = $('knLocChip');
          if (chip) { chip.textContent = '📍 ' + kn.loc.lat.toFixed(3) + ', ' + kn.loc.lng.toFixed(3); chip.classList.add('show'); }
          $('knLocBtn') && $('knLocBtn').classList.add('on');
          resolve(kn.loc);
        },
        (e) => { if (!quiet) toast('Location unavailable: ' + e.message, true); resolve(null); },
        { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 }
      );
    });
  }

  /* ----- command handling ------------------------------------------------- */
  function findPage(t) {
    let best = null, len = 0;
    PAGES.forEach(p => p.words.forEach(w => { if (t.includes(w) && w.length > len) { best = p; len = w.length; } }));
    return best;
  }
  function openPage(id) { if (!requireAuth()) return false; openKnightPage(id); return true; }
  function studioSearch(q) {
    if (!requireAuth()) return;
    openKnightPage('studioPage');
    setStudioTab('categories');
    const i = $('studioSearchInput'); if (i) i.value = q;
    renderStudio();
  }

  /** Returns a reply string if a built-in command handled the text, else null. */
  async function localIntent(raw) {
    const t = raw.toLowerCase().replace(/[.!?,]/g, ' ').replace(/\s+/g, ' ').trim();
    if (!t) return '';
    if (/^(stop|exit|quit|close|go to sleep|goodbye|bye|that'?s all)( knight| ai| assistant| listening)?$/.test(t) || /\b(stop|exit|turn off) (ai|knight|assistant)\b/.test(t)) {
      setAiMode(false); return 'Okay, going quiet. Say “Hey Knight” when you need me.';
    }
    if (/^(help|what can you do)/.test(t)) {
      return 'Try: “open terminal”, “go home”, “open settings”, “search for chat apps”, “show projects near me”, “where am I”, “new project”, “sign out”, or just ask me anything.';
    }
    if (/\b(where am i|my location|find me)\b/.test(t)) {
      const l = kn.loc || await getLocation(false);
      return l ? 'You are around ' + l.lat.toFixed(4) + ', ' + l.lng.toFixed(4) + ' (±' + l.acc + ' m).' : 'I could not get your location. Check the browser permission.';
    }
    if (/\b(near me|nearby|around me|near you)\b/.test(t)) {
      await getLocation(true);
      if (!openPage('studioPage')) return 'Sign in first.';
      setStudioTab('near'); return 'Showing projects near you.';
    }
    if (/\btrending\b/.test(t)) { if (!openPage('studioPage')) return 'Sign in first.'; setStudioTab('trending'); return 'Here is what is trending.'; }
    if (/\b(new|create|start) (a )?(project|repo)\b/.test(t)) { if (!requireAuth()) return 'Sign in first.'; openNewProjectModal(); return 'Opening the new project form.'; }
    if (/\b(sign|log) ?out\b/.test(t)) { setAiMode(false); signOutUI(); return 'Signing you out.'; }
    if (/\b(feedback|report a bug)\b/.test(t)) { if (!requireAuth()) return 'Sign in first.'; openFeedbackUI(); return 'Opening feedback.'; }
    if (/\b(profile|my account)\b/.test(t)) { if (!requireAuth()) return 'Sign in first.'; openModal('profileModal'); return 'Opening your profile.'; }
    if (/^(go )?(home|dashboard)$|\b(go|take me) (to )?(the )?(home|dashboard)\b|\bgo back\b/.test(t)) { if (!requireAuth()) return 'Sign in first.'; goHome(); return 'Back on the dashboard.'; }
    let m = t.match(/^(?:search|find|look up|look for)(?: for)? (.+)$/);
    if (m) { studioSearch(m[1]); return 'Searching projects for “' + m[1] + '”.'; }
    m = t.match(/^(?:open|go to|show|launch|take me to|start)(?: the| my)? (.+)$/);
    if (m) {
      const p = findPage(m[1]);
      if (p) return openPage(p.id) ? 'Opening ' + m[1] + '.' : 'Sign in first.';
    }
    const p = findPage(t);
    if (p && t.split(' ').length <= 3) return openPage(p.id) ? 'Opening ' + t + '.' : 'Sign in first.';
    return null;
  }

  const SYSTEM = 'You are Knight, the voice/command assistant inside the Knight developer workspace website. ' +
    'Reply ONLY with one JSON object, no markdown: {"say":"short friendly reply, max 2 sentences","action":null|{"type":"open","page":"terminal|projects|studio|comm|social|notes|arcade|settings|home"}|{"type":"search","query":"text"}|{"type":"new_project"}|{"type":"near_me"}}. ' +
    'Use an action only when the user clearly asks to navigate or search the site; otherwise answer the question in "say" with action null.';
  const PAGE_IDS = { terminal: 'terminalPage', projects: 'projectsPage', studio: 'studioPage', comm: 'commPage', social: 'socialPage', notes: 'notesPage', arcade: 'arcadePage', settings: 'settingsPage' };

  async function askAi(text) {
    if (typeof aiMode !== 'function' || aiMode() === 'none') {
      return 'AI is not set up yet. Add an OpenRouter key under Settings → AI Assistant (or set OPENROUTER_API_KEY on the server). Built-in commands like “open terminal” still work.';
    }
    const ctx = kn.loc ? ' User location (shared by them): ' + kn.loc.lat.toFixed(3) + ',' + kn.loc.lng.toFixed(3) + '.' : '';
    const msgs = [{ role: 'system', content: SYSTEM + ctx }].concat(kn.history.slice(-6), [{ role: 'user', content: text }]);
    let out;
    try { out = await callAI(msgs); } catch (e) { return 'AI error: ' + (e.message || e); }
    let obj = null;
    const s = String(out.content || '').trim();
    try { obj = JSON.parse(s.slice(s.indexOf('{'), s.lastIndexOf('}') + 1)); } catch (_) {}
    const reply = (obj && obj.say) ? String(obj.say) : s || 'I have no answer for that.';
    kn.history.push({ role: 'user', content: text }, { role: 'assistant', content: reply });
    const a = obj && obj.action;
    if (a && a.type) {
      log('act', '→ ' + a.type + (a.page ? ' ' + a.page : '') + (a.query ? ' “' + a.query + '”' : ''));
      if (a.type === 'open' && a.page === 'home') { requireAuth() && goHome(); }
      else if (a.type === 'open' && PAGE_IDS[a.page]) openPage(PAGE_IDS[a.page]);
      else if (a.type === 'search' && a.query) studioSearch(String(a.query).slice(0, 80));
      else if (a.type === 'new_project' && requireAuth()) openNewProjectModal();
      else if (a.type === 'near_me') { await getLocation(true); if (openPage('studioPage')) setStudioTab('near'); }
    }
    return reply;
  }

  async function runCommand(text, viaVoice) {
    text = (text || '').trim(); if (!text) return;
    if (!kn.aiOn) setAiMode(true);
    bumpIdle();
    log('you', text);
    let reply = await localIntent(text);
    if (reply === null) reply = await askAi(text);
    if (reply) say(reply, viaVoice || kn.spoken);
    bumpIdle();
  }

  /* ----- speech ---------------------------------------------------------- */
  function makeRec(continuous) {
    const r = new SR(); r.lang = navigator.language || 'en-US'; r.continuous = continuous; r.interimResults = false; r.maxAlternatives = 3; return r;
  }
  function oneShotMic() {
    if (!SR) { toast('Voice input is not supported in this browser (try Chrome or Edge).', true); return; }
    if (kn.oneRec) { try { kn.oneRec.stop(); } catch (_) {} return; }
    const btn = $('knMicBtn'); const r = makeRec(false); kn.oneRec = r;
    r.onstart = () => btn.classList.add('listening');
    r.onerror = (e) => { toast('Mic error: ' + e.error, true); };
    r.onend = () => { btn.classList.remove('listening'); kn.oneRec = null; };
    r.onresult = (e) => {
      const said = e.results[0][0].transcript; $('knSearchInput').value = said;
      const wk = stripWake(said);
      runCommand(wk.found ? (wk.rest || '') : said, true);
    };
    try { r.start(); } catch (_) {}
  }

  const WAKE_RE = /\b(?:hey|hay|hi|okay|ok|a)[, ]+(?:knight|night|nite|knights)\b[,.! ]*/i;
  function stripWake(s) { const m = s.match(WAKE_RE); return m ? { found: true, rest: s.slice(m.index + m[0].length).trim() } : { found: false, rest: s }; }

  function startWake() {
    if (!SR) { toast('“Hey Knight” needs speech recognition (Chrome, Edge or Safari).', true); return; }
    if (kn.wake) return;
    kn.wake = true; $('knWakeBtn').classList.add('on');
    const loop = () => {
      if (!kn.wake) return;
      const r = makeRec(true); kn.wakeRec = r;
      r.onresult = (e) => {
        for (let i = e.resultIndex; i < e.results.length; i++) {
          if (!e.results[i].isFinal) continue;
          const heard = e.results[i][0].transcript.trim();
          const wk = stripWake(heard);
          if (wk.found) {
            kn.spoken = true; setAiMode(true); log('act', '🎙 wake word heard');
            if (wk.rest) runCommand(wk.rest, true); else { kn.awaitingCmd = true; say('Yes? I am listening.', true); }
          } else if (kn.aiOn) {
            runCommand(heard, true);   // already awake: treat speech as a command
          }
        }
      };
      r.onerror = (e) => { if (e.error === 'not-allowed' || e.error === 'service-not-allowed') { kn.wake = false; $('knWakeBtn').classList.remove('on'); toast('Microphone permission was blocked.', true); } };
      r.onend = () => { if (kn.wake) setTimeout(loop, 300); };
      try { r.start(); } catch (_) { setTimeout(loop, 1000); }
    };
    loop(); toast('Listening for “Hey Knight”…');
  }
  function stopWake() {
    kn.wake = false; $('knWakeBtn').classList.toggle('on', kn.aiOn);
    try { kn.wakeRec && kn.wakeRec.stop(); } catch (_) {} toast('“Hey Knight” is off.');
  }

  /* ----- build the UI ---------------------------------------------------- */
  const ICON = {
    mic: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/></svg>',
    pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
    spark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l2.2 6.3L21 10l-6.8 1.7L12 18l-2.2-6.3L3 10l6.8-1.7z"/></svg>',
  };
  function build() {
    const target = $('commandPaletteBtn'); if (!target || $('knSearch')) return;
    const bar = document.createElement('div'); bar.className = 'kn-search'; bar.id = 'knSearch';
    bar.innerHTML =
      '<input id="knSearchInput" type="text" autocomplete="off" placeholder="Search or say “Hey Knight”…" aria-label="Search or ask Knight">' +
      '<span class="kn-loc-chip" id="knLocChip"></span>' +
      '<button class="kn-ico-btn" id="knLocBtn" type="button" title="Share my location">' + ICON.pin + '</button>' +
      '<button class="kn-ico-btn" id="knMicBtn" type="button" title="Speak a command">' + ICON.mic + '</button>' +
      '<button class="kn-ico-btn" id="knWakeBtn" type="button" title="Always listen for “Hey Knight”">' + ICON.spark + '</button>';
    target.parentNode.insertBefore(bar, target);

    const dock = document.createElement('div'); dock.id = 'knDock';
    dock.innerHTML = '<div id="knDockHead"><span>⚔ Knight AI</span><button type="button" id="knDockClose" title="Exit AI mode">✕</button></div><div id="knLog"></div>';
    document.body.appendChild(dock);

    $('knSearchInput').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); const v = e.target.value; e.target.value = ''; kn.spoken = false; const wk = stripWake(v); runCommand(wk.found ? (wk.rest || '') : v, false); }
      if (e.key === 'Escape') e.target.blur();
      e.stopPropagation();
    });
    $('knLocBtn').onclick = async () => { const l = await getLocation(false); if (l) toast('Location shared with Knight.'); };
    $('knMicBtn').onclick = oneShotMic;
    $('knWakeBtn').onclick = () => (kn.wake ? stopWake() : startWake());
    $('knDockClose').onclick = () => setAiMode(false, true);
    if (!SR) { $('knMicBtn').title = 'Voice not supported in this browser'; $('knMicBtn').style.opacity = .45; $('knWakeBtn').style.opacity = .45; }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
  window.KnightAssistant = { run: runCommand, setAiMode, getLocation };
})();
